
import java.util.Scanner;
 
  class addwithScanner {
 
public static void main(String []args){

Scanner s = new Scanner(System.in);

int a = s.nextlnt();

int b = s.nextlnt();

System.out.println("sum:" +(a+b));

}

}
 