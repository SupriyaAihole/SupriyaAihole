//helloword

class helloword1
{
public static void main(String arg[])
{
System.out.println("hello world");
}
}