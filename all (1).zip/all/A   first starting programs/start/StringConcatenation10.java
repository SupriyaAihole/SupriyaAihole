public class StringConcatenation10 {

    public static void main(String[] args) {
        String a = "Hello";
        String b = "World";

        String c = a + " " + b;
        System.out.println("Concatenated string: " + c);
    }
}
