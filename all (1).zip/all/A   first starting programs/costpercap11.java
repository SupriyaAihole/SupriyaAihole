public class costpercap11 {

    public static void main(String[] args) {
        int totalCaps = 50;
        int totalPrice = 500;

        double costPerCap = (double) totalPrice / totalCaps;
        System.out.println("The cost of 1 cap is: " + costPerCap);
    }
}
