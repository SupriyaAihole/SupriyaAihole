public class VowelConsonantCheck28 {

  public static void main(String[] args) {
    char letter = 'a';

    if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u') {
      System.out.println(letter + " is a vowel");
    } else {
      System.out.println(letter + " is a consonant");
    }
  }
}
