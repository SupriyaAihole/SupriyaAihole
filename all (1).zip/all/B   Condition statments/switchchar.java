class switchchar {
public static void main(String arg[])
{
char c='x';
switch(c){
 case 'a': System.out.println("A");
 break;
  case 'b': System.out.println("B");
 break;
case 'x': System.out.println("X");
 break;
default:  System.out.println("The character is not a,b,x.");
         break;
}
}
}