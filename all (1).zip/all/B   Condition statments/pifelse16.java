public class pifelse16 {
    public static void main(String[] args) {
        int num = 1000;
        if (num >= 0) {
            System.out.println("The number is positive.");
        } else {
            System.out.println("The number is negative or zero.");
        }
    }
}