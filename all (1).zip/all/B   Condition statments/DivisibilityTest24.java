public class DivisibilityTest24 {

  public static void main(String[] args) {
    int number = 15;

    if (number % 3 == 0) {
      System.out.println("Hello");
    }
    if (number % 5 == 0) {
      System.out.println("Hi");
    }
    if (number % 3 == 0 && number % 5 == 0) {
      System.out.println("Hello Hi");
    }
  }
}
