public class pif15 {
    public static void main(String[] args) {
        int num = -5;
        if (num > 0) {
            System.out.println("The number is positive.");
        }
    }
}