public class pgreat2of22 {
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;
        if (num1 > num2) {
            System.out.println(num1 + " is the greatest number.");
        } else {
            System.out.println(num2 + " is the greatest number.");
        }
    }
}