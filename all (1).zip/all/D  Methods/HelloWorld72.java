public class HelloWorld72 {

    // Method to display the message
    public static void displayMessage() {
        System.out.println("Hello, World!");
    }

    // Main method to execute the program
    public static void main(String[] args) {
        // Call the displayMessage method
        displayMessage();
    }
}
