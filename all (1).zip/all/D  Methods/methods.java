class methods{

public static int square(int number){
 	int s = number*number;
	return  s;
} 
 public static void main(String arg[])
{
int result =  square(5);
System.out.println(result);
}

}