public class WhileLoopExample {
    public static void main(String[] args) {
        int i = 6;
        
        while (i <= 5) {
            System.out.println("Iteration " + i);
            i++;
        }
    }
}
