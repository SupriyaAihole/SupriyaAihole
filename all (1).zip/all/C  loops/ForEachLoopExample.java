public class ForEachLoopExample {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        
        for (int n : numbers) {
            System.out.println("Number: " + n);
        }
    }
}
